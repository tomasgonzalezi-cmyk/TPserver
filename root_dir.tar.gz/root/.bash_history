 poweroff
 poweroff
ls -l /media
ls
ls -l
lsblk
poweroff
lsblk
mkdir -p /mnt/cdrom
mount /dev/sr0 /mnt/cdrom
/mnt/cdrom/VBoxLinuxAdditions.run
reboot
apt update
apt install apache2 -y
systemctl status apache2
apt install php libapache2-mod-php -y
systemctl restart apache2
/mnt/compartida
cp /mnt/compartida/* /var/www/html -r
/var/www/html
ls -l /mnt/compartida
poweroff
ls /mnt/compartida
mkdir -p /mnt/compartida
mount -t vboxsf CA /mnt/compartida
ls /mnt/compartida
cp /mnt/compartida/* /var/www/html/ -r
ls -l /var/www/html/
rm /var/www/html/index.html
ls -l /var/www/html/
systemctl restart apache2
systemctl status apache2
ip a
poweroff
lsblk
df -h
cat /etc/fstab
/opt/scripts/backup_full.sh /var/logs /backup_dir
ls -l /backup_dir
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh /var/logs /backup_dir
/var/log
nano /opt/scrips/backup_full.sh
o
nano /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls -lh /backup_dir
nano /opt/scripts/backup_full.sh
ls -l /
lsblk
ls -l /www_dir
cat /proc/particion
cat /proc/partitions > /root/particion
cat /root/particion
mount --bind /root/particion /proc/particion
cat /proc/particion
mkdir /proc/particion
mkdir /proc/particion
cat /proc/partitions > /root/particion
mount --bind /root/particion /proc/particion
cat /proc/particion
cat /proc/partitions > /root/particion
mkdir /proc/particion
/etc/fstab
cat /etc/fstab
nano /etc/fstab
reboot
nano /etc/fstab
reboot
cat /porc/partitions > /root/particion
cat /proc/partitions > /root/particion
cat /root/particion > /proc/particion
cat /proc/partitions > /root/particion
ls /proc | grep parti
cat /root/particion > /proc/particion
cat /proc/particion
ls -l /root/particion
touch /root/particion
mount --bind /root/particion /proc/particion
ls -l /root/particion
mount -o bind /root /proc
ls /proc/root
cat /proc/partitions > /root/particion
ls -l /root/particion
mkdir /mnt/particion
mount --bind /root/particion /mnt/particion
cat /mnt/particion
rm -f /mnt/particion
rmdirn
rmdir /mnt/particion
mkdir /mnt/particion
mount --bind /root/particion /mnt/particion
cat /mnt/particion
ls -l /root/particion
cat /proc/partitions > /root/particion
echo "" > /proc/particion
cat /root/particion > /proc/particion
ln -s /root/particion /proc/particion
ls -l /proc | grep partic
rm /proc/particion
rm /proc/particion
rm -rf /mnt/particion
rm -rf /mnt/particion
rm -rf /root/particion
ls- l /proc | grep particion
ls -l /proc | grep partic
ls -l /root | grep par
ls -l /proc | grep particion
ls -l /root | grep particion
ls -l /mnt
ls -l /proc/root
-ls
cat /proc/partitions > /root/particion
reroot
reboot
