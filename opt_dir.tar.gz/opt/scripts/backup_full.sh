
#!/bin/bash

if  ["$1" = "-help"] ;  then
     echo "USO: $0  ORIGEN DESTINO"
     echo "EJEMPLO: $0 /var/log /backup_dir"
     exit 0
fi


ORIGEN="$1"
DESTINO="$2"

if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
    echo "ERROR: TE FALTAN PARAMETROS."
    echo "USE: $0 -help"
    exit 1
fi

if [ ! -d "$ORIGEN" ] ; then
    echo "ERROR: EL ORIGEN NO EXISTE:"
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "ERROR: EL DESTINO NO EXISTE."
    exit 1
fi

FECHA="20240302"

NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

echo "backup creado en: $DESTINO/$ARCHIVO" 
