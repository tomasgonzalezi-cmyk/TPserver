/* $Id: RTAssertShouldPanic-generic.cpp 170187 2025-08-11 17:18:47Z klaus $ */
/** @file
 * IPRT - Assertions, generic RTAssertShouldPanic.
 */

/*
 * Copyright (C) 2006-2025 Oracle and/or its affiliates.
 *
 * This file is part of VirtualBox base platform packages, as
 * available from https://www.virtualbox.org.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation, in version 3 of the
 * License.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <https://www.gnu.org/licenses>.
 *
 * The contents of this file may alternatively be used under the terms
 * of the Common Development and Distribution License Version 1.0
 * (CDDL), a copy of it is provided in the "COPYING.CDDL" file included
 * in the VirtualBox distribution, in which case the provisions of the
 * CDDL are applicable instead of those of the GPL.
 *
 * You may elect to license modified versions of this file under the
 * terms and conditions of either the GPL or the CDDL or both.
 *
 * SPDX-License-Identifier: GPL-3.0-only OR CDDL-1.0
 */


/*********************************************************************************************************************************
*   Header Files                                                                                                                 *
*********************************************************************************************************************************/
#include <iprt/assert.h>
#include "internal/iprt.h"

#ifdef IN_RING
# if 0
#  include <iprt/asm.h>
#  include <iprt/asm-amd64-x86.h>
# endif
#endif


RTDECL(bool) RTAssertShouldPanic(void)
{
#ifdef IN_RING0
# if 0 /* this can be useful when debugging guests. */
    ASMIntDisable();
    ASMHalt();
# endif
#endif
#if 0 /* Enable this to not panic on assertions. (Make sure this code is used!) */
    return false;
#else
    return RTAssertMayPanic();
#endif
}
RT_EXPORT_SYMBOL(RTAssertShouldPanic);

